from django.apps import AppConfig


class GenedenConfig(AppConfig):
    name = 'genEden'
