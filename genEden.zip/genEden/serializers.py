# fuente: http://levipy.com/crear-api-rest-con-django-rest-framework/
from rest_framework import serializers
from .models import Maceta,User

class MacetaSerializer(serializers.ModelSerializer):
	class Meta:
		model = Maceta
		fields = ('idMaceta','temperatura','luminosidad','humedad')

class UserSerializer(serializers.ModelSerializer):
	class Meta:
		model = User
		fields = ('idUser','passw','nombre','correo','ciudad','birth')
