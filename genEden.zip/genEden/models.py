from django.db import models

class User(models.Model):
	idUser = models.IntegerField(default=1)
	passw = models.CharField(max_length=100)
	nombre = models.CharField(max_length=100)
	correo = models.CharField(max_length=100)
	ciudad = models.CharField(max_length=100)
	birth = models.CharField(max_length=100)
	# def __init__(self):
	# 	self.idUser = 1
	# 	self.passw = 'eden'
	# 	self.nombre = 'Ciro'
	# 	self.correo = 'cirossj10@hotmail.com'
	# 	self.ciudad = 'Piedecaucho'
	# 	self.birth = '22/6/1996'

class Maceta(models.Model):
	idMaceta = models.IntegerField(default=1)
	temperatura = models.IntegerField(default=1)
	luminosidad = models.IntegerField(default=1)
	humedad = models.IntegerField(default=1)

	# def __init__(self):
	# 	self.idMaceta = 3
	# 	self.temperatura = 22
	# 	self.luminosidad = 56
	# 	self.humedad = 76



